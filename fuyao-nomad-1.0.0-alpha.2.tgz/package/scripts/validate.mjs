#!/usr/bin/env node
/**
 * Validate rosters, plan-progress, and docs/templates against JSON schemas.
 */
import { readFileSync, readdirSync, existsSync, statSync } from "node:fs";
import { join, dirname, isAbsolute, basename } from "node:path";
import { fileURLToPath } from "node:url";
import YAML from "yaml";
import Ajv2020 from "ajv/dist/2020.js";
import addFormats from "ajv-formats";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const SCHEMAS = join(ROOT, "docs/design/schemas");

const ajv = new Ajv2020({ allErrors: true, strict: false });
addFormats(ajv);

function loadSchema(name) {
  return JSON.parse(readFileSync(join(SCHEMAS, name), "utf8"));
}

const validators = {
  roster: ajv.compile(loadSchema("roster.schema.json")),
  plan: ajv.compile(loadSchema("plan-progress.schema.json")),
  dod: ajv.compile(loadSchema("template-dod.schema.json")),
  verification: ajv.compile(loadSchema("template-verification.schema.json")),
  ddd_gate: ajv.compile(loadSchema("template-ddd-gate.schema.json")),
  adr: ajv.compile(loadSchema("template-adr.schema.json")),
  stage: ajv.compile(loadSchema("template-stage.schema.json")),
  commit_policy: ajv.compile(loadSchema("template-commit-policy.schema.json")),
  audit: ajv.compile(loadSchema("audit-record.schema.json")),
  pack: ajv.compile(loadSchema("team-pack.schema.json")),
  message: ajv.compile(loadSchema("message.schema.json")),
  problem_statement: ajv.compile(loadSchema("template-problem-statement.schema.json")),
  prd_lite: ajv.compile(loadSchema("template-prd-lite.schema.json")),
  anti_metrics: ajv.compile(loadSchema("template-anti-metrics.schema.json")),
  adversarial_boundary: ajv.compile(loadSchema("template-adversarial-boundary.schema.json")),
  eval_gates: ajv.compile(loadSchema("template-eval-gates.schema.json")),
};

function parseYaml(path) {
  try {
    return YAML.parse(readFileSync(path, "utf8"));
  } catch (err) {
    throw new Error(`Invalid YAML in ${path}: ${err.message}`);
  }
}

function validateData(data, validateFn, label, path) {
  const ok = validateFn(data);
  if (ok) {
    console.log(`✓ ${label}: ${path}`);
    return true;
  }
  console.error(`✗ ${label}: ${path}`);
  for (const err of validateFn.errors ?? []) {
    console.error(`  ${err.instancePath || "/"} ${err.message}`);
  }
  return false;
}

function classifyTemplate(name) {
  if (name.startsWith("dod-")) return "dod";
  if (name.startsWith("verification-")) return "verification";
  if (name.startsWith("ddd-gate-")) return "ddd_gate";
  if (name.startsWith("adr-") || name.startsWith("ADR-")) return "adr";
  if (name.startsWith("stage-")) return "stage";
  if (name.startsWith("commit-policy-")) return "commit_policy";
  if (name.startsWith("problem-statement-")) return "problem_statement";
  if (name.startsWith("prd-lite-")) return "prd_lite";
  if (name.startsWith("anti-metrics-")) return "anti_metrics";
  if (name.startsWith("adversarial-boundary-")) return "adversarial_boundary";
  if (name.startsWith("eval-gates-")) return "eval_gates";
  return null;
}

function validateFile(path, labelOverride) {
  const name = basename(path);
  const data = parseYaml(path);
  let kind = labelOverride;
  if (!kind) {
    if (name === "pack.yaml") kind = "pack";
    else if (name.endsWith(".audit.yaml")) kind = "audit";
    else if (data?.message) kind = "message";
    else if (name.includes("plan-progress") || name.startsWith("plan-")) kind = "plan";
    else if (name.includes("roster") || name === "minimal-roster.yaml") kind = "roster";
    else kind = classifyTemplate(name);
  }
  if (!kind || !validators[kind]) {
    console.warn(`⚠ skip (unknown type): ${path}`);
    return true;
  }
  return validateData(data, validators[kind], kind, path);
}

function validateDir(dir, filter) {
  if (!existsSync(dir)) return { passed: 0, failed: 0 };
  let passed = 0;
  let failed = 0;
  for (const name of readdirSync(dir)) {
    if (!name.endsWith(".yaml") && !name.endsWith(".yml")) continue;
    if (filter && !filter(name)) continue;
    const ok = validateFile(join(dir, name));
    if (ok) passed++;
    else failed++;
  }
  return { passed, failed };
}

function validateMessagesTree(dir) {
  if (!existsSync(dir)) return { passed: 0, failed: 0 };
  let passed = 0;
  let failed = 0;
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (name.endsWith(".yaml") || name.endsWith(".yml")) {
      const ok = validateFile(p, "message");
      if (ok) passed++;
      else failed++;
    } else if (!name.startsWith(".")) {
      try {
        if (!statSync(p).isDirectory()) continue;
        const sub = validateMessagesTree(p);
        passed += sub.passed;
        failed += sub.failed;
      } catch {
        /* skip */
      }
    }
  }
  return { passed, failed };
}

let passed = 0;
let failed = 0;

const args = process.argv.slice(2);
if (args[0] === "--path" && args[1]) {
  const p = isAbsolute(args[1]) ? args[1] : join(process.cwd(), args[1]);
  // ADR-0005 C 面：--path 显式单文件校验时，未知类型/无法识别为契约文件必须 FAIL
  // （目录扫描内的示例杂文件可 skip；显式指定是契约行为，静默通过=校验器说谎）
  const name = basename(p);
  const data = parseYaml(p);
  let kind = null;
  if (name === "pack.yaml") kind = "pack";
  else if (name.endsWith(".audit.yaml")) kind = "audit";
  else if (data?.message) kind = "message";
  else if (name.includes("plan-progress") || name.startsWith("plan-")) kind = "plan";
  else if (name.includes("roster") || name === "minimal-roster.yaml") kind = "roster";
  else kind = classifyTemplate(name);
  if (!kind || !validators[kind]) {
    console.error(`✗ unknown contract type (refusing to pass): ${p}`);
    console.error(`  --path 指定文件须为可识别契约（roster/plan/message/audit/pack/模板）；目录扫描内杂项才可 skip`);
    failed++;
  } else if (validateData(data, validators[kind], kind, p)) passed++;
  else failed++;
} else {
  const ex = validateDir(join(ROOT, "agents/examples"));
  passed += ex.passed;
  failed += ex.failed;

  const msgEx = validateMessagesTree(join(ROOT, "agents/examples/messages"));
  passed += msgEx.passed;
  failed += msgEx.failed;

  const msgLocal = validateMessagesTree(join(ROOT, ".agents/messages"));
  passed += msgLocal.passed;
  failed += msgLocal.failed;

  const tpl = validateDir(join(ROOT, "docs/templates"), (n) => n !== "README.md");
  passed += tpl.passed;
  failed += tpl.failed;

  const decisions = validateDir(join(ROOT, "docs/decisions"), (n) =>
    n !== "README.md" && (n.startsWith("adr-") || n.startsWith("ADR-")),
  );
  passed += decisions.passed;
  failed += decisions.failed;

  const packsDir = join(ROOT, "packs");
  if (existsSync(packsDir)) {
    for (const name of readdirSync(packsDir)) {
      const packDir = join(packsDir, name);
      const packYaml = join(packDir, "pack.yaml");
      if (!existsSync(packYaml)) continue;
      const ok = validateFile(packYaml, "pack");
      if (ok) passed++;
      else failed++;

      const examplesDir = join(packDir, "examples");
      if (existsSync(examplesDir)) {
        for (const ex of readdirSync(examplesDir)) {
          if (!ex.endsWith(".yaml") && !ex.endsWith(".yml")) continue;
          const exOk = validateFile(join(examplesDir, ex), "message");
          if (exOk) passed++;
          else failed++;
        }
      }
    }
  }
}

console.log(`\n${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
